"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""
import util
from game import Directions, Actions
from problems import SearchProblem

n = Directions.NORTH
s = Directions.SOUTH
e = Directions.EAST
w = Directions.WEST


def depthFirstSearch(problem):
    '''
    return a path to the goal
    '''
    # TODO 17
    # "visited" contains nodes which have been popped from the stack,
    # and the direction from which they were obtained
    visited = {}
    # "solution" contains the sequence of directions for Pacman to get to the goal state
    solution = []
    # "stack" contains triplets of: (node in the fringe list, direction, cost)
    stack = util.Stack()
    # "parents" contains nodes and their parents
    parents = {}

    # start state is obtained and added to the stack
    start = problem.getStartState()
    stack.push((start, 'Undefined', 0))
    # the direction from which we arrived in the start state is undefined
    visited[start] = 'Undefined'

    # return if start state itself is the goal
    if problem.isGoalState(start):
        return solution

    # loop while stack is not empty and goal is not reached
    goal = False;
    while(stack.isEmpty() != True and goal != True):
        # pop from top of stack
        node = stack.pop()
        # store element and its direction
        visited[node[0]] = node[1]
        # check if element is goal
        if problem.isGoalState(node[0]):
            node_sol = node[0]
            goal = True
            break
        # expand node
        for elem in problem.getSuccessors(node[0]):
            # if successor has not already been visited
            if elem[0] not in visited.keys():
                # store successor and its parent
                parents[elem[0]] = node[0]
                # push successor onto stack
                stack.push(elem)

    # finding and storing the path
    while(node_sol in parents.keys()):
        # find parent
        node_sol_prev = parents[node_sol]
        # prepend direction to solution
        solution.insert(0, visited[node_sol])
        # go to previous node
        node_sol = node_sol_prev

    return solution


def breadthFirstSearch(problem):
    '''
    return a path to the goal
    '''
    # TODO 18
    #initialization
    visited = {}
    # "solution" contains the sequence of directions for Pacman to get to the goal state
    solution = []
    # "queue" contains triplets of: (node in the fringe list, direction, cost)
    queue = util.Queue()
    # "parents" contains nodes and their parents
    parents = {}

    # start state is obtained and added to the queue
    start = problem.getStartState()
    queue.push((start, 'Undefined', 0))
    # the direction from which we arrived in the start state is undefined
    visited[start] = 'Undefined'

    # return if start state itself is the goal
    if problem.isGoalState(start):
        return solution

    # loop while queue is not empty and goal is not reached
    goal = False;
    while (queue.isEmpty() != True and goal != True):
        # pop from top of queue
        node = queue.pop()
        # store element and its direction
        visited[node[0]] = node[1]
        # check if element is goal
        if problem.isGoalState(node[0]):
            node_sol = node[0]
            goal = True
            break
        # expand node
        for elem in problem.getSuccessors(node[0]):
            # if successor has not already been visited or expanded as a child of another node
            if elem[0] not in visited.keys() and elem[0] not in parents.keys():
                # store successor and its parent
                parents[elem[0]] = node[0]
                # push successor onto queue
                queue.push(elem)

    # finding and storing the path
    while (node_sol in parents.keys()):
        # find parent
        node_sol_prev = parents[node_sol]
        # prepend direction to solution
        solution.insert(0, visited[node_sol])
        # go to previous node
        node_sol = node_sol_prev

    return solution


def uniformCostSearch(problem):
    '''
    return a path to the goal
    '''
    # TODO 19
    visited = {}
    # "solution" contains the sequence of directions for Pacman to get to the goal state
    solution = []
    # "queue" contains triplets of: (nodes in the fringe list, direction, cost)
    queue = util.PriorityQueue()
    # "parents" contains nodes and their parents
    parents = {}
    # "cost" contains nodes and their corresponding costs
    cost = {}

    # start state is obtained and added to the queue
    start = problem.getStartState()
    queue.push((start, 'Undefined', 0), 0)
    # the direction from which we arrived in the start state is undefined
    visited[start] = 'Undefined'
    # cost of start state is 0
    cost[start] = 0

    # return if start state itself is the goal
    if problem.isGoalState(start):
        return solution

    # loop while queue is not empty and goal is not reached
    goal = False;
    while (queue.isEmpty() != True and goal != True):
        # pop from top of queue
        node = queue.pop()
        # store element and its direction
        visited[node[0]] = node[1]
        # check if element is goal
        if problem.isGoalState(node[0]):
            node_sol = node[0]
            goal = True
            break
        # expand node
        for elem in problem.getSuccessors(node[0]):
            # if successor is not visited, calculate its new cost
            if elem[0] not in visited.keys():
                priority = node[2] + elem[2]
                # if cost of successor was calculated earlier while expanding a different node,
                # if new cost is more than old cost, continue
                if elem[0] in cost.keys():
                    if cost[elem[0]] <= priority:
                        continue
                # if new cost is less than old cost, push to queue and change cost and parent
                queue.push((elem[0], elem[1], priority), priority)
                cost[elem[0]] = priority
                # store successor and its parent
                parents[elem[0]] = node[0]

    # finding and storing the path
    while (node_sol in parents.keys()):
        # find parent
        node_sol_prev = parents[node_sol]
        # prepend direction to solution
        solution.insert(0, visited[node_sol])
        # go to previous node
        node_sol = node_sol_prev

    return solution


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def singleFoodSearchHeuristic(state, problem=None):
    """
    A heuristic function for the problem of single food search
    """
    # TODO 20
    position, foodGrid = state
    H = 0
    maxDistance = 0
    # find the farthest distance by Astar search using mazeDistance() function.
    for y in range(foodGrid.height):
        for x in range(foodGrid.width):
            if (foodGrid[x][y] == 1) and (mazeDistance(position, (x, y), problem.startingGameState) > maxDistance):
                maxDistance = mazeDistance(position, (x, y), problem.startingGameState)
    H = maxDistance
    return H


def multiFoodSearchHeuristic(state, problem=None):
    """
    A heuristic function for the problem of multi-food search
    """
    # TODO 21
    pass


def aStarSearch(problem, heuristic=nullHeuristic):
    '''
    return a path to the goal
    '''
    # TODO 22
    #initialization
    # and the direction from which they were obtained
    visited = {}
    # "solution" contains the sequence of directions for Pacman to get to the goal state
    solution = []
    # "queue" contains triplets of: (node in the fringe list, direction, cost)
    queue = util.PriorityQueue()
    # "parents" contains nodes and their parents
    parents = {}
    # "cost" contains nodes and their corresponding costs
    cost = {}

    # start state is obtained and added to the queue
    start = problem.getStartState()
    queue.push((start, 'Undefined', 0), 0)
    # the direction from which we arrived in the start state is undefined
    visited[start] = 'Undefined'
    # cost of start state is 0
    cost[start] = 0

    # return if start state itself is the goal
    if problem.isGoalState(start):
        return solution

    # loop while queue is not empty and goal is not reached
    goal = False;
    while (queue.isEmpty() != True and goal != True):
        # pop from top of queue
        node = queue.pop()
        # store element and its direction
        visited[node[0]] = node[1]
        # check if element is goal
        if problem.isGoalState(node[0]):
            node_sol = node[0]
            goal = True
            break
        # expand node
        for elem in problem.getSuccessors(node[0]):
            # if successor is not visited, calculate its new cost
            if elem[0] not in visited.keys():
                priority = node[2] + elem[2] + heuristic(elem[0], problem)
                # if cost of successor was calculated earlier while expanding a different node,
                # if new cost is more than old cost, continue
                if elem[0] in cost.keys():
                    if cost[elem[0]] <= priority:
                        continue
                # if new cost is less than old cost, push to queue and change cost and parent
                queue.push((elem[0], elem[1], node[2] + elem[2]), priority)
                cost[elem[0]] = priority
                # store successor and its parent
                parents[elem[0]] = node[0]

    # finding and storing the path
    while (node_sol in parents.keys()):
        # find parent
        node_sol_prev = parents[node_sol]
        # prepend direction to solution
        solution.insert(0, visited[node_sol])
        # go to previous node
        node_sol = node_sol_prev

    return solution


def mazeDistance(point1, point2, gameState):
    """
    Returns the maze distance between any two points, using the search functions
    you have already built. The gameState can be any game state -- Pacman's
    position in that state is ignored.
    Example usage: mazeDistance( (2,4), (5,6), gameState)
    This might be a useful helper function for your ApproximateSearchAgent.
    """
    x1, y1 = point1
    x2, y2 = point2
    walls = gameState.getWalls()
    assert not walls[x1][y1], 'point1 is a wall: ' + str(point1)
    assert not walls[x2][y2], 'point2 is a wall: ' + str(point2)
    prob = PositionSearchProblem(gameState, start=point1, goal=point2, warn=False, visualize=False)
    return len(bfs(prob))

class PositionSearchProblem(SearchProblem):
    """
    A search problem defines the state space, start state, goal test, successor
    function and cost function.  This search problem can be used to find paths
    to a particular point on the pacman board.
    The state space consists of (x,y) positions in a pacman game.
    Note: this search problem is fully specified; you should NOT change it.
    """

    def __init__(self, gameState, costFn = lambda x: 1, goal=(1,1), start=None, warn=True, visualize=True):
        """
        Stores the start and goal.
        gameState: A GameState object (pacman.py)
        costFn: A function from a search state (tuple) to a non-negative number
        goal: A position in the gameState
        """
        self.walls = gameState.getWalls()
        self.startState = gameState.getPacmanPosition()
        if start != None: self.startState = start
        self.goal = goal
        self.costFn = costFn
        self.visualize = visualize
        if warn and (gameState.getNumFood() != 1 or not gameState.hasFood(*goal)):
            print("Warning: this does not look like a regular search maze")

        # For display purposes
        self._visited, self._visitedlist, self._expanded = {}, [], 0 # DO NOT CHANGE

    def getStartState(self):
        return self.startState

    def isGoalState(self, state):
        isGoal = state == self.goal

        # For display purposes only
        if isGoal and self.visualize:
            self._visitedlist.append(state)
            import __main__
            if '_display' in dir(__main__):
                if 'drawExpandedCells' in dir(__main__._display): #@UndefinedVariable
                    __main__._display.drawExpandedCells(self._visitedlist) #@UndefinedVariable

        return isGoal

    def getSuccessors(self, state):
        """
        Returns successor states, the actions they require, and a cost of 1.
         As noted in search.py:
             For a given state, this should return a list of triples,
         (successor, action, stepCost), where 'successor' is a
         successor to the current state, 'action' is the action
         required to get there, and 'stepCost' is the incremental
         cost of expanding to that successor
        """

        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
            x,y = state
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextState = (nextx, nexty)
                cost = self.costFn(nextState)
                successors.append( ( nextState, action, cost) )

        # Bookkeeping for display purposes
        self._expanded += 1 # DO NOT CHANGE
        if state not in self._visited:
            self._visited[state] = True
            self._visitedlist.append(state)

        return successors

    def getCostOfActions(self, actions):
        """
        Returns the cost of a particular sequence of actions. If those actions
        include an illegal move, return 999999.
        """
        if actions == None: return 999999
        x,y= self.getStartState()
        cost = 0
        for action in actions:
            # Check figure out the next state and see whether its' legal
            dx, dy = Actions.directionToVector(action)
            x, y = int(x + dx), int(y + dy)
            if self.walls[x][y]: return 999999
            cost += self.costFn((x,y))
        return cost

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
